# Telstra DevOps CI/CD Project

This repo contains end-to-end infrastructure, pipelines, manifests, and monitoring for the Telstra Node.js app.